#!/bin/bash

cd /build
make
